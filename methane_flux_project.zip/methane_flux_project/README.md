# Prediction of Methane Flux Emission in India Using Machine Learning

## Structure
- `methane_flux_pipeline.py` – full pipeline (EDA, preprocessing, Random Forest, XGBoost, evaluation, importance, map, case study)
- `build_report.py` – regenerates the Word report from the results
- `data/` – input CSV (400 rows, 2020–2023)
- `results/` – metrics, predictions, importances, hyper-parameters, sanity check; `results/figures/` – 10 plots
- `report/Methane_Flux_Prediction_Report.docx` (and PDF)

## Run
    pip install -r requirements.txt
    python methane_flux_pipeline.py
    python build_report.py

## Headline result (this dataset)
Random Forest and XGBoost do not beat a mean-predictor baseline (test R² ≈ 0; CV R² < 0).
A shuffled-target control gives the same R², so the supplied data contain no learnable signal.
The slide values (R² 0.83) could not be reproduced from this CSV.
