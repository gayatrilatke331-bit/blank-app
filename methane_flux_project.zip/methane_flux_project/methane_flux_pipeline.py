"""
Prediction of Methane Flux Emission in India Using Machine Learning
-------------------------------------------------------------------
End-to-end pipeline: EDA -> preprocessing -> Random Forest & XGBoost ->
evaluation -> feature importance -> spatial map -> case study.

Run:  python methane_flux_pipeline.py
Outputs go to ./results (CSV tables) and ./results/figures (PNG plots).
"""
import json
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import (GridSearchCV, KFold, cross_val_score,
                                     train_test_split)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBRegressor

warnings.filterwarnings("ignore")
SEED = 42
ROOT = Path(__file__).parent
DATA = ROOT / "data" / "methane_flux_india_2020_2023.csv"
RES = ROOT / "results"
FIG = RES / "figures"
FIG.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid")

# ------------------------------------------------------------------ 1. LOAD
df = pd.read_csv(DATA)
TARGET = "methane_flux"
NUMERIC = ["latitude", "longitude", "temperature", "rainfall", "ndvi"]
CATEGORICAL = ["land_use_index"]
FEATURES = NUMERIC + CATEGORICAL

summary = {
    "rows": int(len(df)),
    "columns": list(df.columns),
    "missing_values": int(df.isna().sum().sum()),
    "duplicate_rows": int(df.duplicated().sum()),
}
df.describe().T.round(4).to_csv(RES / "descriptive_statistics.csv")

# --------------------------------------------------------------------- 2. EDA
# 2a. target distribution
fig, ax = plt.subplots(1, 2, figsize=(10, 4))
sns.histplot(df[TARGET], kde=True, ax=ax[0], color="#1f77b4")
ax[0].set_title("Distribution of methane flux")
sns.boxplot(x="land_use_index", y=TARGET, data=df, ax=ax[1])
ax[1].set_title("Methane flux by land-use class")
plt.tight_layout(); plt.savefig(FIG / "01_target_distribution.png", dpi=150); plt.close()

# 2b. feature histograms
fig, axes = plt.subplots(2, 3, figsize=(13, 7))
for a, c in zip(axes.ravel(), NUMERIC + ["year"]):
    sns.histplot(df[c], kde=True, ax=a, color="#2ca02c")
    a.set_title(c)
plt.tight_layout(); plt.savefig(FIG / "02_feature_distributions.png", dpi=150); plt.close()

# 2c. correlation matrix
corr = df.corr()
corr.round(4).to_csv(RES / "correlation_matrix.csv")
plt.figure(figsize=(8, 6))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title("Correlation matrix")
plt.tight_layout(); plt.savefig(FIG / "03_correlation_matrix.png", dpi=150); plt.close()

# 2d. flux by year
plt.figure(figsize=(6, 4))
sns.boxplot(x="year", y=TARGET, data=df)
plt.title("Methane flux by year")
plt.tight_layout(); plt.savefig(FIG / "04_flux_by_year.png", dpi=150); plt.close()

# 2e. spatial scatter of observed flux
plt.figure(figsize=(7, 6))
sc = plt.scatter(df.longitude, df.latitude, c=df[TARGET], cmap="YlOrRd", s=35, edgecolor="k", lw=.3)
plt.colorbar(sc, label="Observed CH4 flux")
plt.xlabel("Longitude"); plt.ylabel("Latitude"); plt.title("Observed methane flux (sample points)")
plt.tight_layout(); plt.savefig(FIG / "05_spatial_observed.png", dpi=150); plt.close()

# --------------------------------------------------------- 3. PREPROCESSING
# duplicates/outliers (IQR rule on target - reported, not blindly removed)
q1, q3 = df[TARGET].quantile([.25, .75]); iqr = q3 - q1
n_out = int(((df[TARGET] < q1 - 1.5 * iqr) | (df[TARGET] > q3 + 1.5 * iqr)).sum())
summary["iqr_outliers_in_target"] = n_out
df = df.drop_duplicates().reset_index(drop=True)

X, y = df[FEATURES], df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=SEED)
summary.update(train_rows=int(len(X_train)), test_rows=int(len(X_test)))

def make_preprocessor():
    num = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())])
    cat = Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                    ("oh", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("num", num, NUMERIC), ("cat", cat, CATEGORICAL)])

# ------------------------------------------------------------- 4. MODELLING
models = {
    "Baseline (mean)": (DummyRegressor(strategy="mean"), {}),
    "Random Forest": (RandomForestRegressor(random_state=SEED, n_jobs=-1),
                      {"m__n_estimators": [200, 400], "m__max_depth": [3, 5, None],
                       "m__min_samples_leaf": [1, 5, 10]}),
    "XGBoost": (XGBRegressor(random_state=SEED, n_jobs=-1, verbosity=0),
                {"m__n_estimators": [100, 300], "m__max_depth": [2, 3, 5],
                 "m__learning_rate": [0.01, 0.05, 0.1], "m__subsample": [0.8, 1.0]}),
}
cv = KFold(5, shuffle=True, random_state=SEED)
rows, fitted, best_params = [], {}, {}
for name, (est, grid) in models.items():
    pipe = Pipeline([("prep", make_preprocessor()), ("m", est)])
    if grid:
        gs = GridSearchCV(pipe, grid, cv=cv, scoring="r2", n_jobs=-1).fit(X_train, y_train)
        pipe, best_params[name] = gs.best_estimator_, gs.best_params_
    else:
        pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    cv_r2 = cross_val_score(pipe, X, y, cv=cv, scoring="r2")
    rows.append({"Model": name,
                 "RMSE": mean_squared_error(y_test, pred) ** 0.5,
                 "MAE": mean_absolute_error(y_test, pred),
                 "R2 (test)": r2_score(y_test, pred),
                 "R2 (5-fold CV mean)": cv_r2.mean(),
                 "R2 (5-fold CV std)": cv_r2.std()})
    fitted[name] = (pipe, pred)
metrics = pd.DataFrame(rows).round(4)
metrics.to_csv(RES / "model_metrics.csv", index=False)
json.dump({k: {a.replace("m__", ""): b for a, b in v.items()} for k, v in best_params.items()},
          open(RES / "best_hyperparameters.json", "w"), indent=2, default=str)

# test predictions
pd.DataFrame({"actual": y_test.values,
              "pred_random_forest": fitted["Random Forest"][1],
              "pred_xgboost": fitted["XGBoost"][1]}).round(4).to_csv(RES / "test_predictions.csv", index=False)

# ---------------------------------------------- 5. SANITY CHECK: SHUFFLED y
# If a model scores about the same on a shuffled target, features carry ~no signal.
rng = np.random.RandomState(SEED)
shuf = []
for _ in range(20):
    ys = y_train.sample(frac=1, random_state=rng.randint(1e6)).values
    p = Pipeline([("prep", make_preprocessor()),
                  ("m", XGBRegressor(random_state=SEED, verbosity=0, **{k.replace("m__", ""): v for k, v in best_params["XGBoost"].items()}))])
    p.fit(X_train, ys)
    shuf.append(r2_score(y_test, p.predict(X_test)))
shuffle_stats = {"mean_r2_shuffled_target": float(np.mean(shuf)),
                 "max_r2_shuffled_target": float(np.max(shuf)),
                 "real_xgb_test_r2": float(metrics.loc[metrics.Model == "XGBoost", "R2 (test)"].iloc[0])}
json.dump(shuffle_stats, open(RES / "shuffle_sanity_check.json", "w"), indent=2)

# ---------------------------------------------------------------- 6. PLOTS
plt.figure(figsize=(7, 4))
sns.barplot(data=metrics[metrics.Model != "Baseline (mean)"], x="Model", y="R2 (test)", palette=["#1f77b4", "#ff7f0e"])
plt.axhline(0, color="k", lw=.8); plt.title("Test R² by model")
plt.tight_layout(); plt.savefig(FIG / "06_model_r2_comparison.png", dpi=150); plt.close()

fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
for a, n in zip(ax, ["Random Forest", "XGBoost"]):
    p = fitted[n][1]
    a.scatter(y_test, p, alpha=.7); lim = [y.min(), y.max()]
    a.plot(lim, lim, "r--"); a.set_xlabel("Actual"); a.set_ylabel("Predicted")
    a.set_title(f"{n}: actual vs predicted (R²={r2_score(y_test, p):.3f})")
plt.tight_layout(); plt.savefig(FIG / "07_actual_vs_predicted.png", dpi=150); plt.close()

best = "XGBoost"
res = y_test.values - fitted[best][1]
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].scatter(fitted[best][1], res, alpha=.7); ax[0].axhline(0, color="r", ls="--")
ax[0].set_xlabel("Predicted"); ax[0].set_ylabel("Residual"); ax[0].set_title("XGBoost residuals")
sns.histplot(res, kde=True, ax=ax[1]); ax[1].set_title("Residual distribution")
plt.tight_layout(); plt.savefig(FIG / "08_residuals.png", dpi=150); plt.close()

# feature importance (permutation importance on the raw columns, test set)
fi = []
for n in ["Random Forest", "XGBoost"]:
    pi = permutation_importance(fitted[n][0], X_test, y_test, n_repeats=30, random_state=SEED, scoring="r2")
    for f, m, s in zip(FEATURES, pi.importances_mean, pi.importances_std):
        fi.append({"Model": n, "Feature": f, "Importance_mean": m, "Importance_std": s})
fi = pd.DataFrame(fi).round(4); fi.to_csv(RES / "feature_importance.csv", index=False)
plt.figure(figsize=(8, 4.5))
sns.barplot(data=fi, x="Importance_mean", y="Feature", hue="Model")
plt.axvline(0, color="k", lw=.8); plt.title("Permutation importance (drop in test R²)")
plt.tight_layout(); plt.savefig(FIG / "09_feature_importance.png", dpi=150); plt.close()

# spatial prediction map: predict on a grid using median conditions
glon, glat = np.meshgrid(np.linspace(df.longitude.min(), df.longitude.max(), 60),
                         np.linspace(df.latitude.min(), df.latitude.max(), 60))
grid = pd.DataFrame({"latitude": glat.ravel(), "longitude": glon.ravel(),
                     "temperature": df.temperature.median(), "rainfall": df.rainfall.median(),
                     "ndvi": df.ndvi.median(), "land_use_index": int(df.land_use_index.mode()[0])})
zz = fitted[best][0].predict(grid).reshape(glat.shape)
plt.figure(figsize=(7, 6))
cs = plt.contourf(glon, glat, zz, 15, cmap="YlOrRd")
plt.scatter(df.longitude, df.latitude, c="k", s=6, alpha=.4)
plt.colorbar(cs, label="Predicted CH4 flux")
plt.xlabel("Longitude"); plt.ylabel("Latitude")
plt.title("XGBoost spatial prediction (median climate/NDVI)")
plt.tight_layout(); plt.savefig(FIG / "10_spatial_prediction_map.png", dpi=150); plt.close()

# ------------------------------------------------------ 7. PREDICTION CASE
case = pd.DataFrame([{"latitude": 22.3, "longitude": 72.6, "temperature": 30.0,
                      "rainfall": 1500.0, "ndvi": 0.55, "land_use_index": 3}])
case["predicted_flux_xgboost"] = fitted["XGBoost"][0].predict(case[FEATURES])
case["predicted_flux_random_forest"] = fitted["Random Forest"][0].predict(case[FEATURES])
case.round(4).to_csv(RES / "case_study_prediction.csv", index=False)

json.dump(summary, open(RES / "data_summary.json", "w"), indent=2)
print(metrics.to_string(index=False)); print(shuffle_stats); print(summary)
print(case.round(3).to_string(index=False))
