import pandas as pd, json
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

R = Path("results"); F = R / "figures"
m = pd.read_csv(R / "model_metrics.csv")
fi = pd.read_csv(R / "feature_importance.csv")
sh = json.load(open(R / "shuffle_sanity_check.json"))
bp = json.load(open(R / "best_hyperparameters.json"))
case = pd.read_csv(R / "case_study_prediction.csv").iloc[0]
ds = pd.read_csv(R / "descriptive_statistics.csv").rename(columns={"Unnamed: 0": "variable"})

d = Document()
st = d.styles["Normal"]; st.font.name = "Times New Roman"; st.font.size = Pt(12)
for s, sz in [("Heading 1", 16), ("Heading 2", 13)]:
    d.styles[s].font.name = "Times New Roman"; d.styles[s].font.size = Pt(sz)
    d.styles[s].font.color.rgb = RGBColor(0, 0, 0)
for sec in d.sections:
    sec.left_margin = sec.right_margin = Inches(1); sec.top_margin = sec.bottom_margin = Inches(1)

def P(t, bold=False, align=None, size=None, italic=False):
    p = d.add_paragraph(); r = p.add_run(t); r.bold = bold; r.italic = italic
    if size: r.font.size = Pt(size)
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    else: p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    return p
def B(t):
    d.add_paragraph(t, style="List Bullet")
def fig(name, cap, w=5.8):
    d.add_picture(str(F / name), width=Inches(w)); d.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    P(cap, italic=True, align="c", size=10)
def table(df, widths=None):
    t = d.add_table(rows=1, cols=len(df.columns)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, c in enumerate(df.columns):
        t.rows[0].cells[i].text = str(c)
        for r in t.rows[0].cells[i].paragraphs[0].runs: r.bold = True
    for _, row in df.iterrows():
        cells = t.add_row().cells
        for i, v in enumerate(row): cells[i].text = f"{v:.4f}" if isinstance(v, float) else str(v)
    for row in t.rows:
        for c in row.cells:
            for p in c.paragraphs:
                for r in p.runs: r.font.size = Pt(10)
    d.add_paragraph()

# ---- title page
for _ in range(4): d.add_paragraph()
P("PREDICTION OF METHANE FLUX EMISSION IN INDIA USING MACHINE LEARNING", True, "c", 20)
d.add_paragraph()
P("Project Report", False, "c", 14)
P("Academic Year: 2024–2025", False, "c", 13)
for _ in range(3): d.add_paragraph()
P("Submitted by: Ravi", True, "c", 13)
P("MSc Agriculture Analytics", False, "c", 12)
P("Dhirubhai Ambani University (DAU)", False, "c", 12)
P("[Add guide / supervisor name and enrolment number here]", False, "c", 11, True)
d.add_page_break()

# ---- abstract
d.add_heading("Abstract", 1)
P("Methane (CH4) is a potent greenhouse gas, and agriculture is among India's largest sources. This project builds "
  "a supervised machine-learning pipeline to predict methane flux from latitude, longitude, temperature, rainfall, "
  "NDVI and a land-use class using a dataset of 400 geo-located observations for 2020–2023. Two ensemble regressors, "
  "Random Forest and XGBoost, were tuned with 5-fold cross-validation on an 80% training split and compared with a "
  "mean-predictor baseline using RMSE, MAE and R². On this dataset neither model improved on the baseline "
  f"(test R² = {m.loc[1,'R2 (test)']:.3f} for Random Forest and {m.loc[2,'R2 (test)']:.3f} for XGBoost), and "
  "the correlations between flux and every predictor are below 0.08 in absolute value. A shuffled-target control "
  "gave the same R², which indicates that this dataset carries no learnable signal for these features. The report "
  "documents the full workflow, the results, and the limitations, and recommends the data improvements needed "
  "before methane flux can be modelled reliably.")
d.add_page_break()

# ---- 1 intro
d.add_heading("1. Introduction", 1)
P("Methane has a much higher global warming potential than carbon dioxide over a 20-year horizon. In India, rice "
  "paddies, livestock and wetlands produce complex, spatially varying emission patterns. Traditional estimation "
  "relies on costly field chambers or inventory factors, which are sparse and cannot capture dynamic interactions "
  "between climate, soil and vegetation. Data-driven models that use satellite and climate variables offer a scalable alternative.")
d.add_heading("1.1 Problem statement", 2)
B("Methane flux depends on non-linear interactions between temperature, moisture, rainfall and vegetation.")
B("Emissions vary across regions and seasons, so static estimates are inaccurate.")
B("Manual measurements are sparse; an automated, scalable approach is needed.")
d.add_heading("1.2 Objectives", 2)
B("Develop regression models to estimate CH4 flux from environmental variables.")
B("Compare Random Forest and XGBoost using RMSE, MAE and R².")
B("Identify which variables drive predictions and map predicted flux spatially.")
B("Assess whether the available data can support policy-relevant estimation.")

# ---- 2 data
d.add_heading("2. Data Description", 1)
P("The dataset (methane_flux_india_2020_2023.csv) contains 400 rows and 8 columns: 100 observations for each year from "
  "2020 to 2023. There are no missing values and no duplicate rows. The target is methane_flux. The predictors are "
  "latitude, longitude, temperature (°C), rainfall (mm), NDVI and land_use_index (integer classes 1–6, treated as categorical). "
  "The year column is retained for exploration but not used as a predictor.")
table(ds[["variable", "mean", "std", "min", "50%", "max"]].round(3))
P("Note: the presentation lists soil moisture and pressure as features, but these two variables are not present in the "
  "supplied dataset, so they are not used here.", italic=True)

d.add_heading("2.1 Data source", 2)
P("The dataset was supplied as a CSV file (methane_flux_india_2020_2023.csv) by the author. Its original provider, collection method, "
  "spatial resolution and flux units were not documented, so the data could not be traced to a specific archive. "
  "[Replace this paragraph with the exact source and download date if it becomes known.]")
P("For a validated study, the variables in this project are normally obtained from the following public sources (recommended sources, not the confirmed origin of the supplied file):")
B("Methane: Sentinel-5P TROPOMI CH4 (Copernicus / ESA), GOSAT (JAXA/NIES), or bottom-up inventories such as EDGAR (European Commission JRC).")
B("Temperature, rainfall and soil moisture: ERA5-Land reanalysis (Copernicus Climate Data Store) or IMD gridded data.")
B("NDVI and land cover: MODIS MOD13 (NDVI) and MCD12 (land cover), NASA Earthdata; all accessible through Google Earth Engine.")

# ---- 3 method
d.add_heading("3. Methodology", 1)
d.add_heading("3.1 Pre-processing", 2)
B("Median imputation (numeric) and most-frequent imputation (categorical) are built into the pipeline; the data had no missing values, so no values changed.")
B("Duplicates were checked (none) and the target was screened with the 1.5×IQR rule (no outliers), so no rows were removed.")
B("land_use_index was one-hot encoded; numeric features were standardised. Scaling does not affect tree models but keeps the pipeline reusable.")
B("Data were split 80/20 (320 training, 80 test rows) with random_state = 42. All transformations are fitted on the training data only, inside a scikit-learn Pipeline, to avoid leakage.")
d.add_heading("3.2 Models", 2)
P("Random Forest is a bagging ensemble of decision trees that averages many de-correlated trees. XGBoost is a gradient-boosting "
  "ensemble that builds trees sequentially, each correcting the residuals of the previous ones, with regularisation. "
  "A DummyRegressor that always predicts the training mean serves as the baseline.")
d.add_heading("3.3 Tuning and evaluation", 2)
P("Hyper-parameters were chosen by grid search with 5-fold cross-validation on the training set (scoring = R²). "
  f"Selected values — Random Forest: {bp['Random Forest']}; XGBoost: {bp['XGBoost']}. Final performance is reported on the held-out test set "
  "(RMSE, MAE, R²), and also as the mean R² of 5-fold cross-validation over all 400 rows, which is more stable than a single 80-row test split.")

# ---- 4 EDA
d.add_heading("4. Exploratory Data Analysis", 1)
fig("01_target_distribution.png", "Figure 1: Distribution of methane flux and flux by land-use class.")
P("Methane flux ranges from about 1.0 to 5.0 with a mean of 3.03 and a roughly flat distribution. Flux is spread similarly across all six land-use classes.")
fig("03_correlation_matrix.png", "Figure 2: Correlation matrix.", 5.2)
P("Correlations between methane flux and the predictors are very weak: NDVI +0.061, latitude −0.077, longitude −0.059, temperature −0.039, "
  "rainfall −0.032, land-use index +0.001, year −0.002. No variable shows a strong relationship with flux, and the predictors are also "
  "uncorrelated with one another.")
fig("02_feature_distributions.png", "Figure 3: Distribution of predictor variables.")
P("Latitude, longitude, temperature, rainfall and NDVI are close to uniformly distributed over their ranges, and the land-use classes are about equally frequent.")
fig("05_spatial_observed.png", "Figure 4: Observed methane flux at the 400 sample points.", 4.6)
P("The sample points are scattered over a bounding box that extends beyond India's land area, and high and low flux values are intermixed "
  "rather than clustered; no distinct hotspots are visible in the observed data.")

# ---- 5 results
d.add_heading("5. Results", 1)
d.add_heading("5.1 Model performance", 2)
table(m)
fig("06_model_r2_comparison.png", "Figure 5: Test R² of Random Forest and XGBoost.", 4.6)
P("Both models have an R² at or below zero on the test set and in cross-validation, and an RMSE (about 1.09–1.10) equal to the baseline, "
  "whose RMSE is essentially the standard deviation of the target (1.16 over all rows). In other words, the models predict no better than the mean flux.")
fig("07_actual_vs_predicted.png", "Figure 6: Actual vs predicted flux on the test set.")
P("Predictions are compressed around the mean (about 3) regardless of the actual value, which is the pattern expected when features contain no signal.")
fig("08_residuals.png", "Figure 7: XGBoost residuals.")
d.add_heading("5.2 Shuffled-target control", 2)
P(f"To test whether any signal exists, XGBoost was refitted 20 times on randomly shuffled targets. The mean test R² was {sh['mean_r2_shuffled_target']:.3f} "
  f"(maximum {sh['max_r2_shuffled_target']:.3f}), versus {sh['real_xgb_test_r2']:.3f} for the real target. The real model is therefore indistinguishable "
  "from a model trained on noise, confirming that the features do not explain flux in this dataset.")
d.add_heading("5.3 Feature importance", 2)
fig("09_feature_importance.png", "Figure 8: Permutation importance (drop in test R²).", 5.2)
P("Permutation importances are all close to zero and smaller than their standard deviations (largest: longitude in Random Forest, about 0.03 ± 0.02), "
  "so no variable can be called an important driver. The presentation's claim that soil moisture and NDVI are the most critical predictors is not supported by this dataset: "
  "soil moisture is not in the data, and NDVI's importance is not distinguishable from zero.")
d.add_heading("5.4 Spatial prediction and case study", 2)
fig("10_spatial_prediction_map.png", "Figure 9: XGBoost predicted flux over the sampled area at median climate and NDVI.", 4.6)
P("The predicted surface varies only within a narrow band around the mean, so it should be read as a demonstration of the mapping workflow rather than as evidence of real hotspots.")
P(f"Case study: for latitude 22.3, longitude 72.6, temperature 30 °C, rainfall 1500 mm, NDVI 0.55 and land-use class 3, XGBoost predicts a flux of "
  f"{case['predicted_flux_xgboost']:.2f} and Random Forest {case['predicted_flux_random_forest']:.2f}; both are close to the dataset mean of 3.03.")

# ---- 6 discussion
d.add_heading("6. Discussion", 1)
P("Tree ensembles can capture non-linear relationships, but only when the inputs contain information about the target. Here the correlations, "
  "model scores, permutation importances and the shuffled-target control all agree that the six predictors carry no usable information about flux. Likely reasons are: "
  "(i) the predictors and target appear to be independently sampled, which is characteristic of synthetic or placeholder data; (ii) key physical drivers "
  "such as soil moisture, water-table depth, rice-paddy area and livestock density are absent; (iii) 400 points over a large area and four years "
  "is very sparse; and (iv) the flux units, scale and source are not documented.")
P("Reproducibility note: the earlier presentation reports XGBoost R² = 0.8335, RMSE = 0.0223 and MAE = 0.0181. These could not be reproduced from the supplied CSV. "
  "That RMSE is far below the target's standard deviation (1.16), which would require a differently scaled target or a different dataset. "
  "Before submitting or presenting, the figures in this report should be used, or the original dataset and code behind the slides should be located and the "
  "numbers reconciled.")

# ---- 7 conclusion
d.add_heading("7. Conclusion", 1)
P("A complete, reproducible machine-learning pipeline was built for methane-flux regression, including pre-processing, tuned Random Forest and XGBoost models, "
  "cross-validated evaluation, permutation importance, a spatial map and a prediction example. On the supplied dataset, neither model outperforms a mean predictor "
  f"(XGBoost test R² = {m.loc[2,'R2 (test)']:.3f}, CV R² = {m.loc[2,'R2 (5-fold CV mean)']:.3f}), and the evidence indicates the data contain no learnable relationship. "
  "The workflow itself is sound and can be reused once suitable data are available.")
d.add_heading("8. Limitations", 1)
B("Small sample (400 rows) and no temporal structure within sites; points are not repeated measurements of the same location.")
B("Soil moisture, pressure and named land-cover categories mentioned in the project plan are not in the dataset.")
B("Random train/test splitting; with real spatial data a spatial or year-based split would be a stricter test.")
B("Data provenance and flux units are undocumented.")
d.add_heading("9. Future Scope", 1)
B("Replace the dataset with real satellite and reanalysis data (e.g. Sentinel-5P / GOSAT CH4, ERA5-Land soil moisture and temperature, MODIS NDVI and land cover, wetland and rice-area maps).")
B("Add soil moisture, water-table depth, rice-paddy and livestock density as predictors.")
B("Use spatial cross-validation and year-held-out validation; add SHAP for interpretation.")
B("Try LSTM/CNN for spatio-temporal forecasting and deploy a dashboard for policymakers.")
d.add_heading("References", 1)
for r in ["IPCC (2021). Climate Change 2021: The Physical Science Basis. Cambridge University Press.",
          "Breiman, L. (2001). Random Forests. Machine Learning, 45(1), 5–32.",
          "Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings of KDD 2016.",
          "Pedregosa, F. et al. (2011). Scikit-learn: Machine learning in Python. JMLR, 12, 2825–2830.",
          "NASA Earthdata (earthdata.nasa.gov); Google Earth Engine documentation (developers.google.com/earth-engine)."]:
    B(r)

# ---- appendices: results + code
d.add_page_break()
d.add_heading("Appendix A: Result Tables", 1)
d.add_heading("A.1 Model performance", 2)
table(m)
d.add_heading("A.2 Permutation feature importance", 2)
table(fi)
d.add_heading("A.3 Correlation of each variable with methane flux", 2)
cm = pd.read_csv(R / "correlation_matrix.csv", index_col=0)["methane_flux"].round(4).reset_index()
cm.columns = ["variable", "correlation with methane_flux"]
table(cm)
d.add_heading("A.4 Prediction case study", 2)
table(pd.read_csv(R / "case_study_prediction.csv"))
d.add_heading("A.5 First 15 test-set predictions", 2)
table(pd.read_csv(R / "test_predictions.csv").head(15))
d.add_heading("A.6 Shuffled-target control", 2)
table(pd.DataFrame([sh]))

def code_block(path):
    p = d.add_paragraph()
    p.paragraph_format.space_after = Pt(0)
    lines = Path(path).read_text().split("\n")
    for i, line in enumerate(lines):
        r = p.add_run(line); r.font.name = "Courier New"; r.font.size = Pt(7.5)
        if i < len(lines) - 1: r.add_break()

d.add_page_break()
d.add_heading("Appendix B: Source Code", 1)
d.add_heading("B.1 methane_flux_pipeline.py (EDA, preprocessing, models, evaluation)", 2)
code_block("methane_flux_pipeline.py")

d.save("report/Methane_Flux_Prediction_Report.docx")
